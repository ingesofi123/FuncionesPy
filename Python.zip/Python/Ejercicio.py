def peso ():
    masa = float(input("Digite su masa: "))
    pesoTierra = masa * 9,81
    print("Peso en la Tierra: ", pesoTierra)
    print("----------------------------------------" + "\n")

def moneda (di,do):
    return di*do

def capital ():
    capitalInicial = float(input("Digite el capital inicial: "))
    tasaIntereses = float(input("\n" + "Digite la tasa de interes: "))
    meses = float(input("\n" + "Digite la cantidad de meses: "))
    interesInicial = (capitalInicial * tasaIntereses) / 100
    interesMeses = interesInicial * meses
    print("El interes obtenido es:")
    print("Capital inicial: " , capitalInicial)
    print("Tasa de interes: " , tasaIntereses)
    print("Meses: " , meses)
    print(" Su capital es de " , interesMeses)


def salida ():
 print("\n" + "Gracias por utilizar este programa, vuelva pronto!")
 
print("MENU")
print("Opcion 1: Conocer una masa en diferentes astros")
print("Opcion 2: Convertir un valor de pesos colombianos a otros tipos de moneda")
print("Opcion 3: Conocer el interes que se obtiene de un capital mensual")
print("Opcion 4: Salir")
opcion = int(input("Digite la opción que desee: "))

if (opcion == 1):
    peso()

elif (opcion == 2):
    dinero = float(input("Digite la cantidad de dinero que desea convertir: "))
    dolar= 0.00025
    res=moneda(dinero,dolar)
    print("Su dinero en otros tipos de moneda es: ")
    print("Valor en dorales TRM: ", res)


elif (opcion == 3):
    capital ()

elif (opcion == 4):
   salida()

else:
    print("La opción " , opcion , " es invalida :(, intenta de nuevo!" + "\n")